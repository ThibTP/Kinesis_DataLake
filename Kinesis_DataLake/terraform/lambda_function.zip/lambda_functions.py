import json
import boto3
from datetime import datetime

s3 = boto3.client('s3')


def lambda_handler(event, context):
    try:
        processed_event_uuids = set()  # Set to store processed event UUIDs

        for record in event['Records']:
            payload = json.loads(record['kinesis']['data'])
            # Extract required fields
            event_uuid = payload['event_uuid']
            event_name = payload['event_name']
            created_at = payload['created_at']
            # Transform data
            created_datetime = datetime.utcfromtimestamp(created_at).isoformat()
            event_type, event_subtype = event_name.split(':')[:2]

            # Check if event_uuid is already processed
            if event_uuid not in processed_event_uuids:
                # Store processed event in S3
                s3.put_object(
                    Bucket='your-bucket-name',
                    Key=f'events/{event_type}/{created_datetime}/{event_uuid}.json',
                    Body=json.dumps(payload)
                )
                # Add event_uuid to the set of processed event UUIDs
                processed_event_uuids.add(event_uuid)
            else:
                print(f"Duplicate event detected with UUID: {event_uuid}")
    except Exception as e:
        # Log error message
        print(f"Error processing event: {e}")
        # Optionally, implement retry logic for transient errors
